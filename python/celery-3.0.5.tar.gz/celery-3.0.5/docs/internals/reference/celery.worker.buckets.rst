======================================================
 celery.worker.buckets
======================================================

.. contents::
    :local:
.. currentmodule:: celery.worker.buckets

.. automodule:: celery.worker.buckets
    :members:
    :undoc-members:
