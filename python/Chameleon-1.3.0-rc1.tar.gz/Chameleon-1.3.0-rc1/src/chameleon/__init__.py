__import__('pkg_resources').declare_namespace(__name__)
# no imports are allowed here!
