.. _static_module:

:mod:`pyramid.static`
---------------------

.. automodule:: pyramid.static

  .. autoclass:: static_view
     :members:
     :inherited-members:

