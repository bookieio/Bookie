def includeme(config):
    config.scan('pyramid.tests.pkgs.viewdecoratorapp')
    
