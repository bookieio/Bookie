:tocdepth: 2

.. _changes:

Changes in Sphinx
*****************

.. include:: ../CHANGES
