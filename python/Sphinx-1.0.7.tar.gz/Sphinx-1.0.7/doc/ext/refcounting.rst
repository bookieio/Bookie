:mod:`sphinx.ext.refcounting` -- Keep track of reference counting behavior
==========================================================================

.. module:: sphinx.ext.refcounting
   :synopsis: Keep track of reference counting behavior.

.. todo:: Write this section.
