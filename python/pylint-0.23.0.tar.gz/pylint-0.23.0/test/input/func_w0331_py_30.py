"""check use of <>
"""

__revision__ = 1

if __revision__ <> 2:
    __revision__ = 2 
