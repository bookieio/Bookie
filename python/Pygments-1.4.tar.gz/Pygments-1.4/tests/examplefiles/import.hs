import "mtl" Control.Monad.Trans

main :: IO ()
main = putStrLn "hello world"
