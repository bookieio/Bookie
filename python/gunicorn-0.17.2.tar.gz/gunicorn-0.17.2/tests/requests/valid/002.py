request = {
    "method": "GET",
    "uri": uri("/test"),
    "version": (1, 1),
    "headers": [
        ("USER-AGENT", "curl/7.18.0 (i486-pc-linux-gnu) libcurl/7.18.0 OpenSSL/0.9.8g zlib/1.2.3.3 libidn/1.1"),
        ("HOST", "0.0.0.0=5000"),
        ("ACCEPT", "*/*")
    ],
    "body": b""
}
