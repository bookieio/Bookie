VERSION = '0.1.11'
import client
from scripts import newtest
