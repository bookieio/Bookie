from main import encode, decode, uuid, get_alphabet, set_alphabet
